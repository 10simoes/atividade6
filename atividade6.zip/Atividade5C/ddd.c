#include<stdio.h>

int main(){

    int num;

    printf("\n Digite um DDD: ");
    scanf("%d",&num);

    switch(num){

        case 61:printf("\nBrasilia");break;

        case 71:printf("\nSalvador");break;

        case 11:printf("\nSao Paulo");break;

        case 21:printf("\nRio de Janeiro");break;

        case 32:printf("\nJuiz de Fora");break;

        case 19:printf("\nCampinas");break;

        case 27:printf("\nVitoria");break;

        case 31:printf("\nBelo Horizonte");break;

        default:printf("Uma cidade no Brasil sem identificacao");


    }
}